# KahootGPT Privacy Policy
KahootGPT does not collect any information. However it will store information to your computer locally. You have the option to cache/store your OpenAI API Key, other settings options are stored without option.

If you decide to purchase "Auto-tap", ExtensionPay will save your Email, while Stripe may keep your credit card information.

---------------------------------------

ExtensionPay Github: https://github.com/Glench/ExtPay

Stripe Privacy Policy: https://stripe.com/en-ca/legal/privacy-center  
Stripe Terms of Service: https://stripe.com/en-ca/legal/end-users