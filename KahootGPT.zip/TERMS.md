# Terms of Service

By using KahootGPT, you agree to the following terms and conditions:

1. KahootGPT is provided "as is" without any warranty of any kind, express or implied. We are not responsible for any damages that may arise from the use of the extension.

2. You are solely responsible for your use of KahootGPT and for any content that you generate or access through the extension.

3. You agree to use KahootGPT only for lawful purposes and in compliance with all applicable laws and regulations.

4. We reserve the right to modify or discontinue KahootGPT at any time, without notice.

5. We reserve the right to update these terms of service at any time, without notice. Your continued use of KahootGPT after any such changes will constitute your acceptance of the new terms.

6. We do not collect or store any personal information through KahootGPT. However, third-party services used by KahootGPT, such as ExtensionPay and Stripe, may collect data. Please refer to their respective privacy policies for more information.

7. By using KahootGPT, you agree to indemnify and hold us harmless from any claims, damages, or expenses arising out of your use of the extension.

## Contact Us
If you have any questions or concerns about this Terms of Service, please contact us at itsmarzzzzzz@protonmail.com.